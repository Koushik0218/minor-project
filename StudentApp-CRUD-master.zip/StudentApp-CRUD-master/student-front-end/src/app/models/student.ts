export interface Student {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
}
